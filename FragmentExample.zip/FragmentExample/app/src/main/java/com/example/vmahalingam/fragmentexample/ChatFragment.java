package com.example.vmahalingam.fragmentexample;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import static android.content.ContentValues.TAG;



public class ChatFragment extends Fragment {


    @Nullable

    public static ArrayList<Chat> gg = new ArrayList<Chat>();
    public static ListView listView;

    public static ChatAdapter chatAdapter;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_chat, container, false);

    }


    @Override
    public void onStart() {
        super.onStart();


        listView = (ListView) getView().findViewById(R.id.listView1);


        SetupUserId sid = new SetupUserId();
        String userId = sid.getUserId();

//        gg.add(new Chat(R.drawable.hii, "Hii", "9833867290"));
//        gg.add(new Chat(R.drawable.hii, "Hii", "9833867290"));
//        gg.add(new Chat(R.drawable.hii, "Hii", "9833867290"));
//        gg.add(new Chat(R.drawable.hii, "Hii", "9833867290"));
//        gg.add(new Chat(R.drawable.hii, "Hii", "9833867290"));
//        gg.add(new Chat(R.drawable.hii, "Hii", "9833867290"));


        GetTodos1Task gt = new GetTodos1Task(getActivity(),userId);
        gt.execute();

//        Intent intent1 = new Intent(getActivity(),FetchVisitingCardService.class);
//        this.getActivity().startService(intent1);


//        ChatAdapter chatAdapter = new ChatAdapter(getActivity(), R.layout.listview_item_row, gt.al);
//     listView.setAdapter(chatAdapter);





    }


}








