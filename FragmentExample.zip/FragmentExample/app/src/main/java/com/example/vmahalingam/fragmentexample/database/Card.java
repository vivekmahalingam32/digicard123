package com.example.vmahalingam.fragmentexample.database;

public class Card {


    public static final String TABLE_NAME = "local_cards";
    public static final String COLUMN_IMAGE_VIEW = "image";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_CARD_ID = "card_id";
    public static final String COLUMN_PHONE_NUMBER = "phone_number";
    public static final String COLUMN_SAVED_FLAG ="saved_flag";
    public static final String COLUMN_IMAGE_PATH ="image_path";
    public static final String COLUMN_PHONE = "phone";
    public static final String COLUMN_EMAIL = "email";


   private int id;
    private int image;
    private String cardId;
private String image_path;

    private String phone_number;
    private String savedFlag;

    private String phone;
    private String email;


    public Card(){

    }

    public  Card(int id,int image,String cardId,String savedFlag,String phone_number,String image_path){
this.id = id;
        this.image = image;
        this.cardId = cardId;
        this.phone_number = phone_number;
        this.savedFlag = savedFlag;
        this.image_path=image_path;

    }

    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_IMAGE_VIEW+" INTEGER,"
                    + COLUMN_CARD_ID + " TEXT,"
                    + COLUMN_PHONE_NUMBER+" INTEGER,"
                    + COLUMN_SAVED_FLAG + " TEXT,"
                    + COLUMN_IMAGE_PATH+ " TEXT"

                    + ")";

    public int getId() {
        return id;
    }

    public String getCardId() {
        return cardId;
    }

    public String getSavedFlag() {
        return savedFlag;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public void setSavedFlag(String savedFlag) {
        this.savedFlag = savedFlag;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;

    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getImage_path() {
        return image_path;
    }

    public void setImage_path(String image_path) {
        this.image_path = image_path;
    }

}



