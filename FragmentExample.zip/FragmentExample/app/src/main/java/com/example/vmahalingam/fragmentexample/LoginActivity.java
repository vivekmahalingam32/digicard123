package com.example.vmahalingam.fragmentexample;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.vmahalingam.fragmentexample.database.Card;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    String userName;
    String password;
    EditText userNameText;
    EditText passwordText;
    Button loginButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        loginButton = findViewById(R.id.loginbutton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userNameText = (EditText)findViewById(R.id.userNameText);
                userName= userNameText.getText().toString();
                passwordText = (EditText)findViewById(R.id.passwordText);
                password = passwordText.getText().toString();


                LoginTask lt = new LoginTask(getApplicationContext(),userName,password);
                lt.execute();

            }
        });




    }
}
class LoginTask extends AsyncTask<Void,Void,Void>{

String jsonStr;
String receivedUserName;
String receivedPassword;
Context mContext;


    public LoginTask(Context context,String username,String password){
    this.mContext = context;
    this.receivedUserName = username;
    this.receivedPassword = password;


    }

    @Override
    protected Void doInBackground(Void... voids) {


        HttpHandler sh = new HttpHandler();
        jsonStr = sh.makeServiceCall("https://gentle-bastion-77567.herokuapp.com/users");


        try {
            JSONObject jsonObject = new JSONObject(jsonStr);
            JSONArray contacts = jsonObject.getJSONArray("users");
            for (int i = 0; i < contacts.length(); i++) {
                JSONObject c = contacts.getJSONObject(i);
                String username = c.getString("username");
                String password = c.getString("password");

                if(username.contentEquals(receivedUserName)&&password.contentEquals(receivedPassword)){

                    Log.e("Tag", "LoginException:");
                    SetupUserId sid = new SetupUserId();
                    sid.setUserId(username);
                    Intent intentLogin = new Intent(mContext,MainActivity.class);
                    //intentLogin.putExtra("userid",username);
                    intentLogin.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mContext.startActivity(intentLogin);


                }
                //localCards.add(new Card(i, R.drawable.hii, "hello123", savedFlag, text));


            }


        } catch (final JSONException e) {




        }

        return null;
    }
}
