package com.example.vmahalingam.fragmentexample;

import android.util.Log;

public class StoreInLocalDatabase {

    public void storeInDb(){


        Log.e("tag","Inside store method");
    }


}
