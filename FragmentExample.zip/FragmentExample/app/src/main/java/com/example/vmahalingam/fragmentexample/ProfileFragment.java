package com.example.vmahalingam.fragmentexample;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

public class ProfileFragment extends Fragment {


    public static ListView listViewProfile;





    public static CardAdapter chatAdapterProfile;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile,container,false);
        
    }

    @Override
    public void onStart() {



        SetupUserId sid = new SetupUserId();
       String userID = sid.getUserId();


        listViewProfile = (ListView) getView().findViewById(R.id.listView2);

        GetLocalCards gl = new GetLocalCards(getActivity(),userID);
        gl.execute();






        super.onStart();
    }
}



