package com.example.vmahalingam.fragmentexample;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.util.Log;

import com.example.vmahalingam.fragmentexample.database.Card;
import com.example.vmahalingam.fragmentexample.database.CardDetailsHelper;
import com.example.vmahalingam.fragmentexample.database.CardHelper;
import com.example.vmahalingam.fragmentexample.database.CardDetails;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

public class FetchVisitingCard extends AsyncTask<Void,Void,Void> {


    String userId;



    private Context mContext;

File imgFile;

    public FetchVisitingCard(String userId){

        this.userId = userId;
    }


    @Override
    protected Void doInBackground(Void... voids) {

        Log.e(TAG, "/data/data/com.example.vmahalingam.fragmentexample/"+userId +".jpg");

         imgFile = new  File("//data/data/com.example.vmahalingam.fragmentexample/"+userId +".jpg");










        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {

        if(imgFile.exists()){

            Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());

            StoredCardDetails.CardImage.setImageBitmap(myBitmap);


        }

        //



//        StoredCardDetails.email.setText(email);
//        StoredCardDetails.phone.setText(phone);








    }
}
