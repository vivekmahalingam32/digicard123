package com.example.vmahalingam.fragmentexample;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

public class MjobExecuter extends AsyncTask<Void,Void,String> implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener  {


    protected Context mContext;

    protected static final int MY_PERMISSIONS_REQUEST_FINE_LOCATION = 111;
    protected final String LOG_TAG = "VivekApp";
    protected Location mLastLocation;
    protected GoogleApiClient mGoogleApiClient;
    private Activity mActivity;
    private String currentLocation;
    private LocationRequest mLocationRequest;





    protected MjobExecuter(Context mContext,Activity mActivity){
        this.mContext = mContext;
        this.mActivity = mActivity;

    }

    @Override
    protected String doInBackground(Void... voids) {

        mGoogleApiClient = new GoogleApiClient.Builder(mContext).addApi(LocationServices.API).addConnectionCallbacks(this).addOnConnectionFailedListener(this).build();
        mGoogleApiClient.connect();
        SetupUserId sid1 = new SetupUserId();
        String userId = sid1.getUserId();
        if(currentLocation!=null) {
            HttpHandler sh = new HttpHandler();
            sh.makeServiceCall("https://gentle-bastion-77567.herokuapp.com/todos1234/" + userId + "&" + currentLocation);
        }
        return currentLocation;
    }



    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mLocationRequest = LocationRequest.create();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(10000);

        if (ActivityCompat.checkSelfPermission(mContext, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mContext, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            ActivityCompat.requestPermissions(mActivity,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},MY_PERMISSIONS_REQUEST_FINE_LOCATION);
            return;
        }

        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

        if(mLastLocation!=null){

            currentLocation = String.valueOf(mLastLocation.getLatitude());
        }
        //Log.i(LOG_TAG,"GoogleApiClient connection has been connected"+String.valueOf(mLastLocation.getLongitude()));
        Log.i(LOG_TAG,"GoogleApiClient connection has been connected");

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {

        currentLocation = String.valueOf(location.getLongitude());
        Log.i(LOG_TAG,"GoogleApiClient connection has been connected"+String.valueOf(location.getLongitude()));


    }
}