package com.example.vmahalingam.fragmentexample;

import android.app.Activity;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.widget.Toast;

public class MjobScheduler extends JobService {

    private MjobExecuter mjobExecuter;
    private Activity mActivity;

    public MjobScheduler(){


    }
    public MjobScheduler(Activity activity){
        this.mActivity = activity;

    }

    // @SuppressLint("StaticFieldLeak")
    @Override
    public boolean onStartJob(final JobParameters jobParameters) {





        mjobExecuter = new MjobExecuter(getApplicationContext(),mActivity) {
                @Override
                protected void onPostExecute(String s) {

                    NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(getApplicationContext(), "0")
                            .setSmallIcon(R.drawable.ic_launcher_background)
                            .setContentTitle("Hello")
                            .setContentText(s)
                            .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                    NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getApplicationContext());

                    notificationManager.notify(0, mBuilder.build());

                    Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
                    jobFinished(jobParameters, false);


//                    UpdateLocationTask up = new UpdateLocationTask();
//                    up.execute();


//                    HttpHandler sh = new HttpHandler();
//                    sh.makeServiceCall("https://arcane-basin-62191.herokuapp.com/todos1234/vivek&900");


                }
            };


        mjobExecuter.execute();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        mjobExecuter.cancel(true);
        return false;
    }


}
