package com.example.vmahalingam.fragmentexample;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.util.Log;

import com.example.vmahalingam.fragmentexample.database.Card;
import com.example.vmahalingam.fragmentexample.database.CardDetailsHelper;
import com.example.vmahalingam.fragmentexample.database.CardHelper;
import com.example.vmahalingam.fragmentexample.database.CardDetails;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

public class GetLocalCardsDetails extends AsyncTask<Void,Void,Void> {


    ArrayList<Card> localCards = new ArrayList<Card>();
    Bitmap jsonStr;
    BitmapDrawable bitmapDrawable;


    List<Card> ls ;
    ArrayList<Card> savedLocalCards = new ArrayList<Card>();
int cardNo  = 0;
    String userId;
    ArrayList<Card> aq = new ArrayList<Card>();
    ArrayList<CardDetails> aq1 = new ArrayList<CardDetails>();
String phone;
String email;


    ArrayList<String>as = new ArrayList<String>();
    List<CardDetails> ls1;
    ArrayList<Card> sla;



    private Context mContext;



    public GetLocalCardsDetails(Context context, ArrayList<Card> sla){

        this.mContext = context;
        this.sla= sla;
    }


    @Override
    protected Void doInBackground(Void... voids) {



           HttpHandler sh = new HttpHandler();

for(int k=0;k<sla.size();k++){



    jsonStr = sh.makeServiceCallForImage("https://gentle-bastion-77567.herokuapp.com/display");
    bitmapDrawable = new BitmapDrawable(jsonStr);

    File file = new File("/data/data/com.example.vmahalingam.fragmentexample/" + sla.get(k).getCardId()+".jpg");

    try {
        OutputStream out = new FileOutputStream(file);
        jsonStr.compress(Bitmap.CompressFormat.JPEG, 85, out);
        out.close();
        //MediaStore.Images.Media.insertImage(getContentResolver(),file.getAbsolutePath(),file.getName(),file.getName());

    } catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }



}










        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {



      //  StoredCardDetails.CardImage.setImageBitmap(jsonStr);



//        StoredCardDetails.email.setText(email);
//        StoredCardDetails.phone.setText(phone);








    }
}
