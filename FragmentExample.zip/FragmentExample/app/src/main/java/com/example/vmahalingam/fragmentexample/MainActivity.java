package com.example.vmahalingam.fragmentexample;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ShareActionProvider;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private DrawerLayout drawer;
   String userId;
    private ShareActionProvider mShareActionProvider;

    private static final int JOB_ID = 101;
    private JobScheduler jobScheduler;
    private JobInfo jobInfo;
    protected static final int MY_PERMISSIONS_REQUEST_FINE_LOCATION = 111;
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        Intent intent123 = getIntent();
//        userId = intent123.getStringExtra("userid");
//        setUserId(userId);
       // Log.e("hiio", "Json parsing error: " +userId);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        drawer = findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawer,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);

        drawer.addDrawerListener(toggle);
        toggle.syncState();

        if(savedInstanceState==null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new MessageFragment()).commit();

            navigationView.setCheckedItem(R.id.nav_message);


        }




        MjobScheduler mjobScheduler = new MjobScheduler(this);

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.

            ActivityCompat.requestPermissions(this,new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},MY_PERMISSIONS_REQUEST_FINE_LOCATION);
            // return;
        }

        ComponentName componentName = new ComponentName(this,MjobScheduler.class);

        JobInfo.Builder builder = new JobInfo.Builder(JOB_ID,componentName);
        PersistableBundle bundle = new PersistableBundle();


        builder.setPeriodic(5000);
        builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);

        builder.setPersisted(true);

        jobInfo = builder.build();
        jobScheduler = (JobScheduler)getSystemService(JOB_SCHEDULER_SERVICE);

startJob();

    }

    @Override
    public void onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);

        }else{
            super.onBackPressed();

        }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

switch (item.getItemId()){

    case R.id.nav_message:


        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new MessageFragment()).commit();

        break;
    case R.id.nav_chat:
//       Intent intent123 = new Intent(getApplicationContext(),FetchVisitingCardService.class);
//        startService(intent123);

       getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new ChatFragment()).commit();
//getSupportFragmentManager().executePendingTransactions();
        break;
    case R.id.nav_profile:
//        Intent intent124 = new Intent(this,ProfileFragment.class);
//        intent124.putExtra("userid",userid);
     getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new ProfileFragment()).commit();



//        Intent intent123 = new Intent(getApplicationContext(),Main3Activity.class);
//        startActivity(intent123);
        break;

    case R.id.nav_share:
        Toast.makeText(this,"Share",Toast.LENGTH_SHORT).show();
        break;

    case R.id.nav_send:
        Toast.makeText(this,"Send",Toast.LENGTH_SHORT).show();
        break;


}
drawer.closeDrawer(GravityCompat.START);
        return true;

    }


    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.share, menu);

//        MenuItem item = menu.findItem(R.id.menu_item_share);
//
//        mShareActionProvider = (ShareActionProvider) MenuItemCompat.getActionProvider(item);


        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item){

        switch (item.getItemId()) {
            case R.id.share:

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "This is my text to send.");
                sendIntent.setType("text/plain");
                startActivity(Intent.createChooser(sendIntent, getResources().getText(R.string.send_to)));
                return true;
            default:
                return super.onOptionsItemSelected(item);


        }


        //return true;
    }

    public void startJob(){
        jobScheduler.schedule(jobInfo);
        Toast.makeText(this,"Job Scheduled..",Toast.LENGTH_LONG).show();

    }

    public void stopJob(){

        jobScheduler.cancel(JOB_ID);
        Toast.makeText(this,"Job Cancelled..",Toast.LENGTH_LONG).show();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopJob();
    }
}
