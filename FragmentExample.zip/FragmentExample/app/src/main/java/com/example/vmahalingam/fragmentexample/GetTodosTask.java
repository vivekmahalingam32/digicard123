package com.example.vmahalingam.fragmentexample;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.example.vmahalingam.fragmentexample.database.Card;
import com.example.vmahalingam.fragmentexample.database.CardHelper;

import org.json.JSONException;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

class GetTodos1Task extends AsyncTask<Void,Void,Void> {

    ArrayList<Card> al = new ArrayList<Card>();
    List<Card> ls ;
    String userId;


    String jsonStr;
    private Context mContext;


    public GetTodos1Task(Context context,String userId){
        this.mContext = context;
this.userId = userId;
    }

    @Override
    protected Void doInBackground(Void... voids) {


        CardHelper ch = new CardHelper(mContext);
        ls = ch.getAllSavedNotes();

        al = (ArrayList<Card>)ls;






//      HttpHandler sh = new HttpHandler();
//
//        //
//
//         jsonStr =sh.makeServiceCall("http://10.0.2.2:3000/todos");
//                //"{\"todos\":[{\"_id\":\"5b1a2a0efb6fc033f87f6be6\",\"text\":\"cook dinner\",\"completedAt\":null,\"completed\":false},{\"_id\":\"5b1a2e537611aeab6453d526\",\"text\":\"hiio\",\"completedAt\":124,\"completed\":true},{\"_id\":\"5b1a5013da19f10014a4d1fd\",\"text\":\"qwerty\",\"__v\":0,\"completedAt\":null,\"completed\":false}]}";
//
//        try{
//            JSONObject jsonObject = new JSONObject(jsonStr);
//            JSONArray contacts = jsonObject.getJSONArray("todos");
//            for (int i = 0; i < contacts.length(); i++) {
//                JSONObject c = contacts.getJSONObject(i);
//                String _id = c.getString("_id");
//                String text = c.getString("text");
//                al.add(new Chat(R.drawable.hii,_id,text));
//
//
//
//
//            }
//
//
//        }
//        catch (final JSONException e){
//            Log.e(TAG, "Json parsing error: " + e.getMessage());
//
//        }













     return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {

        ArrayList<Card> sal = new ArrayList<Card>();
        for(int q=0;q<al.size();q++){

            if(al.get(q).getPhone_number().contentEquals(userId))
            {
                sal.add(al.get(q));

            }
        }

        ChatFragment.chatAdapter = new ChatAdapter(this.mContext, R.layout.listview_item_row, sal);
        ChatFragment.listView.setAdapter(ChatFragment.chatAdapter);


    }


}






