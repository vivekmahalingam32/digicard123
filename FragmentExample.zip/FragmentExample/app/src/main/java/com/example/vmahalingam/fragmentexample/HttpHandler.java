
package com.example.vmahalingam.fragmentexample;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.widget.Toast;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.UnknownServiceException;

public class HttpHandler {

    private static final String TAG = HttpHandler.class.getSimpleName();
    //private static String reqUrl = " http://10.0.2.2:3000/api/genres";


    JSONObject postDataParams = new JSONObject();

    public HttpHandler() {
    }

    public String makeServiceCall(String reqUrl) {



        String response= null;





        try {
            URL url = new URL(reqUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            Log.e(TAG, "the location url is : " + reqUrl);
            conn.setRequestMethod("GET");

            // read the response
            InputStream in = conn.getInputStream();

            if(in==null){

                return "hii";
            }
            else{

                response = convertStreamToString(in);

            }
            conn.disconnect();

        } catch (MalformedURLException e) {
            Log.e(TAG, "MalformedURLException: " + e.getMessage());
        } catch (ProtocolException e) {
            Log.e(TAG, "ProtocolException: " + e.getMessage());
        } catch (IOException e) {
            Log.e(TAG, "IOException: " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "Exception: " + e.getMessage());
            //Log.e(TAG, "Exception: " + conn.getResponseCode());
        }

        return response;



        //HttpURLConnection conn ;
        // String pre = "{genre:";


    }


    public Bitmap makeServiceCallForImage(String reqUrl) {




        InputStream in = null;
        String response= null;
        Bitmap myBitmap = null;
        final String PREFIX = "stream2file";
        final String SUFFIX = ".tmp";




        try {
            URL url = new URL(reqUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();


            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.connect();


            // read the response
            in = conn.getInputStream();

            myBitmap = BitmapFactory.decodeStream(in);















            if(myBitmap==null){

                Log.e(TAG, "StreamisNull: ");
            }
            else{

                response = convertStreamToString(in);

            }
            conn.disconnect();

        } catch (MalformedURLException e) {
            Log.e(TAG, "MalformedURLException: " + e.getMessage());
        } catch (ProtocolException e) {
            Log.e(TAG, "ProtocolException: " + e.getMessage());
        } catch (IOException e) {
            Log.e(TAG, "IOException: " + e.getMessage());
            Log.e(TAG, "hello chellam: ");
        } catch (Exception e) {
            Log.e(TAG, "Exception: " + e.getMessage());
            //Log.e(TAG, "Exception: " + conn.getResponseCode());
        }

        return myBitmap;



        //HttpURLConnection conn ;
        // String pre = "{genre:";


    }

    private String convertStreamToString(InputStream is) {

        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return sb.toString();
    }

    public String update(String reqUrl) {

        String response = null;
        Log.e(TAG, "Exception: " + reqUrl);

        try {
            URL url = new URL(reqUrl);
            HttpURLConnection conn1 = (HttpURLConnection) url.openConnection();

            conn1.setRequestMethod("GET");
            InputStream in = conn1.getInputStream();
            response = convertStreamToString(in);
            Log.e(TAG, "Exception: " + reqUrl);

            // read the response
            //InputStream in = conn.getInputStream();
            // response = convertStreamToString(in);
        } catch (MalformedURLException e) {
            Log.e(TAG, "MalformedURLException: " + e.getMessage());
        } catch (ProtocolException e) {
            Log.e(TAG, "ProtocolException: " + e.getMessage());
        } catch (IOException e) {
            Log.e(TAG, "IOException: " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "Exception: " + e.getMessage());
            //Log.e(TAG, "Exception: " + conn.getResponseCode());
        }


        return response;

    }


}
