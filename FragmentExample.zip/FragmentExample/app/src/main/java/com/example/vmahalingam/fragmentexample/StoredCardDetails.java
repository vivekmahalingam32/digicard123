package com.example.vmahalingam.fragmentexample;

import android.content.Intent;
import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.vmahalingam.fragmentexample.database.CardDetails;
import com.example.vmahalingam.fragmentexample.database.CardDetailsHelper;

import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

public class StoredCardDetails extends AppCompatActivity {

public static TextView phone;
public static TextView email;
public static ImageView CardImage;
   public List<CardDetails> ls1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stored_card_details);


Intent intent = getIntent();
String userId = intent.getStringExtra("send");
CardImage = findViewById(R.id.CardImage123);



//
        FetchVisitingCard fvc = new FetchVisitingCard(userId);
        fvc.execute();

    }
}



