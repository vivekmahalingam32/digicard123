package com.example.vmahalingam.fragmentexample;

public class Chat {

    private int mImageDrawable;

    private String mTitle;

    private String mPhone;

    public Chat(int mImageDrawable,String mTitle,String mPhone){
        this.mImageDrawable = mImageDrawable;
        this.mPhone = mPhone;
        this.mTitle = mTitle;

    }


    public int getmImageDrawable() {
        return mImageDrawable;
    }

    public void setmImageDrawable(int mImageDrawable) {
        this.mImageDrawable = mImageDrawable;
    }

    public String getmPhone() {
        return mPhone;
    }

    public void setmPhone(String mPhone) {
        this.mPhone = mPhone;
    }

    public String getmTitle() {
        return mTitle;
    }

    public void setmTitle(String mTitle) {
        this.mTitle = mTitle;
    }
}
