package com.example.vmahalingam.fragmentexample;

public class SetupUserId {

    private static String userId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }


}
