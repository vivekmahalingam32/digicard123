package com.example.vmahalingam.fragmentexample.database;

public class CardDetails {
    public static final String TABLE_NAME = "local_card_details";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_CARD_ID = "card_id";
    public static final String COLUMN_PHONE_NUMBER = "phone_number";
    public static final String COLUMN_EMAIL ="saved_flag";


    private int id;

    private String cardId;

    private String phone_number;
    private String email;

    public CardDetails(){

    }

    public  CardDetails(int id,String cardId,String phone_number,String email){
        this.id = id;
        this.cardId = cardId;
        this.phone_number = phone_number;
        this.email = email;

    }

    public static final String CREATE_TABLE1 =
                    TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_CARD_ID + " TEXT, "
                    + COLUMN_PHONE_NUMBER + " INTEGER, "
                    + COLUMN_EMAIL + " TEXT"
                    + ")";


    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
