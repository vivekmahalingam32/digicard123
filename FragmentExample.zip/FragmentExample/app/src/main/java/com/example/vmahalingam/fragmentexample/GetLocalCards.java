package com.example.vmahalingam.fragmentexample;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;

import com.example.vmahalingam.fragmentexample.database.Card;
import com.example.vmahalingam.fragmentexample.database.CardDetailsHelper;
import com.example.vmahalingam.fragmentexample.database.CardHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

public class GetLocalCards extends AsyncTask<Void,Void,Void> {


    ArrayList<Card> localCards = new ArrayList<Card>();
    String jsonStr;
    List<Card> ls ;
    ArrayList<Card> savedLocalCards = new ArrayList<Card>();

    String userId;
    ArrayList<Card> aq = new ArrayList<Card>();





    private Context mContext;


    public GetLocalCards(Context context,String userId){
        this.mContext = context;
        this.userId = userId;

    }


    @Override
    protected Void doInBackground(Void... voids) {



        CardHelper ch = new CardHelper(mContext);
        CardDetailsHelper cdh = new CardDetailsHelper(mContext);
        ls = ch.getAllNotesByUserId(userId);
        int cardNo = 0;
        int  cardIndex = ch.getCardCount1();


       // cardNo = ch.getCardCount(userId);
        Log.e(TAG, "Json parsing cardno: " +cardNo);










        HttpHandler sh = new HttpHandler();
    jsonStr = sh.makeServiceCall("https://gentle-bastion-77567.herokuapp.com/todos");


    try {
        JSONObject jsonObject = new JSONObject(jsonStr);
        JSONArray contacts = jsonObject.getJSONArray("todos");
        for (int i = 0; i < contacts.length(); i++) {
            JSONObject c = contacts.getJSONObject(i);
            String savedFlag = c.getString("completed");
            //String id = c.get;
            String text = c.getString("text");
            String userCard = c.getString("userCard");
            String phone = c.getString("phone");
            String email = c.getString("email");
            String imagepath = c.getString("imagepath");

if(userCard.contentEquals(userId)){

    JSONArray havingCard = c.getJSONArray("havingCard");

    for(int p =0;p<havingCard.length();p++){
        String havingCardString = havingCard.optString(p);
        //  Log.e(TAG, "Json parsing error: " + havingCardString);
        localCards.add(new Card(cardNo,R.drawable.hii,havingCardString,"hello124",userCard,imagepath));
        cardNo++;
        //    Log.e(TAG, "Json parsing error: " +jhavingCardArray.optString(p));




    }


}








          //  String havingCard = c.getString("havingCard");




        }


    } catch (final JSONException e) {

    Log.e(TAG, "Json parsing error:exception "+ e.getMessage());


    }

        //long h1 = ch.insertCard(localCards);
        //ls = ch.getAllNotes();

        for(int a = 0;a<localCards.size();a++){
            Log.e(TAG, "Json parsing localcards: " +a+localCards.get(a).getCardId()+localCards.get(a).getId());
        }


if(ch.getCardCount(userId)<localCards.size()){

if(ch.getCardCount(userId)==0) {

    NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(mContext, "0")
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setContentTitle("Hello")
            .setContentText("You have got cards to view")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT);

    NotificationManagerCompat notificationManager = NotificationManagerCompat.from(mContext);

    notificationManager.notify(0, mBuilder.build());

}


for(int r = ch.getCardCount(userId);r<localCards.size();r++){

    aq.add(new Card(cardIndex,localCards.get(r).getImage(),localCards.get(r).getCardId(),localCards.get(r).getSavedFlag(),localCards.get(r).getPhone_number(),localCards.get(r).getImage_path()));
//aq1.add(new CardDetails(cardIndex,localCards.get(r).getCardId(),localCards))

    cardIndex++;


    NotificationCompat.Builder mBuilder1 = new NotificationCompat.Builder(mContext, "0")
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setContentTitle("Hello")
            .setContentText("You have got a new card from " +localCards.get(r).getCardId())
            .setPriority(NotificationCompat.PRIORITY_DEFAULT);

    NotificationManagerCompat notificationManager = NotificationManagerCompat.from(mContext);

    notificationManager.notify(0, mBuilder1.build());


}
        long h = ch.insertCard(aq);




       // long s = cdh.insertCard(aq);

        ls = ch.getAllNotesByUserId(userId);




}


for(int y =0;y<ls.size();y++){
    Log.e(TAG, "Json parsing ls: " + ls.get(y).getCardId()+ls.get(y).getId());

}




for(int r =0;r<ls.size();r++){

    if((ls.get(r).getSavedFlag().equalsIgnoreCase("hello124"))){
       savedLocalCards.add(ls.get(r));
      //  Log.e(TAG, "Json parsing error: " + ls.get(r).getCardId().toString());
    }
}






        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {

ArrayList<Card> sla = new ArrayList<Card>();




for(int q=0;q<savedLocalCards.size();q++){

    if(savedLocalCards.get(q).getPhone_number().contentEquals(userId))
    {
        sla.add(savedLocalCards.get(q));
        //Log.e(TAG, "Json parsing error: " +ls.get(q).getCardId());

    }


}
ArrayList<String> as = new ArrayList<String>();
    ProfileFragment.chatAdapterProfile = new CardAdapter(this.mContext, R.layout.listview_item_row, sla);
    ProfileFragment.listViewProfile.setAdapter(ProfileFragment.chatAdapterProfile);



    GetLocalCardsDetails glcd = new GetLocalCardsDetails(mContext,sla);
    glcd.execute();














    }
}
