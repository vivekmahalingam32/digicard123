package com.example.vmahalingam.fragmentexample;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.vmahalingam.fragmentexample.database.Card;
import com.example.vmahalingam.fragmentexample.database.CardHelper;

import java.util.ArrayList;

public class CardAdapter extends ArrayAdapter<Card> {


    Context context;
    int layoutResourceId;
    ArrayList<Card> data = null;


    public CardAdapter(Context context,int layoutResourceId,ArrayList<Card>data){


        super(context,layoutResourceId,data);


        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;

    }


    @NonNull
    @Override
    public View getView(int position, @Nullable final View convertView, @NonNull ViewGroup parent) {

        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(context).inflate(R.layout.listview_item_row,parent,false);

        final Card currentCard = data.get(position);

        ImageView imageView = (ImageView)listItem.findViewById(R.id.imgIcon);
        imageView.setImageResource(currentCard.getImage());

        final TextView phone = (TextView)listItem.findViewById(R.id.txtPhone);
        phone.setText(currentCard.getCardId());

        phone.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent((Activity)context,StoredCardDetails.class);
                myIntent.putExtra("send",phone.getText().toString());
                context.startActivity(myIntent);

            }
        });

        TextView title = (TextView)listItem.findViewById(R.id.txtTitle);
        title.setText(currentCard.getSavedFlag());





        Button buttonSave = (Button)listItem.findViewById(R.id.buttonSave);
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                currentCard.setSavedFlag("true");
               // Toast.makeText(context,currentCard.getSavedFlag(),Toast.LENGTH_SHORT).show();

               // convertView.setVisibility(View.INVISIBLE);
                CardHelper ch = new CardHelper(getContext());
                ch.saveCard(currentCard);

                Activity a = (Activity)getContext();
                ((Activity) getContext()).recreate();





            }
        });

        final Button buttonDelete = (Button)listItem.findViewById(R.id.buttonDelete);
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                currentCard.setSavedFlag("false");
                Toast.makeText(context,currentCard.getSavedFlag(),Toast.LENGTH_SHORT).show();

                // convertView.setVisibility(View.INVISIBLE);
              CardHelper ch = new CardHelper(getContext());
                ch.saveCard(currentCard);

                Activity a = (Activity)getContext();
                ((Activity) getContext()).recreate();







            }

        });



        return listItem;
    }
}
