package com.example.vmahalingam.fragmentexample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

public class ChatActivity extends AppCompatActivity {
    public  ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

      getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        listView = (ListView)findViewById(R.id.listView1);
        GetTodos1Task gt = new GetTodos1Task(this,"hii");
        gt.execute();


        ChatAdapter chatAdapter = new ChatAdapter(this, R.layout.listview_item_row, gt.al);
        listView.setAdapter(chatAdapter);



    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                Intent intent123 = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent123);
                break;
        }

        return true;
    }
}



