package com.example.vmahalingam.fragmentexample;



import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.example.vmahalingam.fragmentexample.database.Card;
import com.example.vmahalingam.fragmentexample.database.CardHelper;

import org.json.JSONException;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

class SendCardTask extends AsyncTask<Void,Void,Void> {

    ArrayList<Card> al = new ArrayList<Card>();
    List<Card> ls ;
    String toId;

    SetupUserId suid = new SetupUserId();

    String fromId = suid.getUserId();




    String jsonStr;
    private Context mContext;


    public SendCardTask(Context context,String toId){
        this.mContext = context;
        this.toId = toId;
    }

    @Override
    protected Void doInBackground(Void... voids) {


String requrl = "https://gentle-bastion-77567.herokuapp.com/todos/"+fromId +"&"+toId;



    HttpHandler hp = new HttpHandler();
      hp.makeServiceCall(requrl);

























        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {



    }


}







